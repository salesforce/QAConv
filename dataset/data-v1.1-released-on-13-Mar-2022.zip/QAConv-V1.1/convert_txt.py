import json
import os

mapping = {
    "trn": "train",
    "val": "val", 
    "tst": "test"
}

article_json = json.load(open("./article_segment.json"))

output_dir = "./nmt"
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

for dtype in ["trn", "val", "tst"]:
    src_all, tgt_all = [], []
    ques_json = json.load(open("./{}.json".format(dtype)))
    for qa_pair in ques_json:
        context = article_json[qa_pair["article_segment_id"]]["seg_dialog"]
        context = " ".join(['{}: {}'.format(c["speaker"], c["text"].replace("\n", " ")) for c in context])
        src = "{} </s> {}".format(qa_pair["question"].strip(), context.strip())
        if len(qa_pair["answers"]):
            tgt = qa_pair["answers"][0].strip() # here we only use the first potential answers
        else: # unanswerable
            tgt = "unanswerable"
        src_all.append(src)
        tgt_all.append(tgt)

    with open("{}/{}.source".format(output_dir, mapping[dtype]), "w") as fout:    
        fout.write("\n".join(src_all))
    with open("{}/{}.target".format(output_dir, mapping[dtype]), "w") as fout:    
        fout.write("\n".join(tgt_all))

